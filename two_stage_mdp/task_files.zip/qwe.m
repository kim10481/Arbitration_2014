function [out]=qwe()

clear all
clear mex
out=1;

end

